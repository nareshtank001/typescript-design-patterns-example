import { TurnstileState } from './TurnstileState';
import { LockedState } from './LockedState';

export class TurnstileFSM {
    public state: TurnstileState;
    constructor() {
        this.state = new LockedState();
    }

    coin(): void {
        this.state.coin(this);
    }

    pass(): void {
        this.state.pass(this);
    }

    lock():void {
        console.log('lock');
    }
    
    unlock():void {
        console.log('unlock');
    }
    
    thankYou():void {
        console.log('thankYou');
    }
    
    alarm():void {
        console.log('alarm');
    }
}