import { TurnstileFSM } from './TurnstileFSM';
import { TurnstileState } from './TurnstileState';
import { UnlockedState } from './UnlockedState';

export class LockedState implements TurnstileState{
    coin(turnstile: TurnstileFSM): void {
       turnstile.state = new UnlockedState();
       turnstile.unlock();
    }
    pass(turnstile: TurnstileFSM): void {
        turnstile.alarm();
    }       
}